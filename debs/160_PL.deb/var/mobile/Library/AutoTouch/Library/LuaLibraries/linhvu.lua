local LinhVu = {}

local function request(url)
    local baseUrl = "http://localhost:3004/";
    local http = require("socket.http")
    print(baseUrl .. url);

    local body, code, headers, status = http.request(baseUrl .. url);
    print(code, status, #body)
end

function LinhVu.backup(bundle)
    local url = "app/backup?bundle=" .. bundle;
    request(url);

end
function LinhVu.wipe(bundle)
    local url = "app/wipe?bundle=" .. bundle;
    request(url);
end

function LinhVu.restore(folder)
    local url = "app/restore?folder=" .. folder;
    request(url);

end

function LinhVu.delete(folder)
    local url = "app/delete?folder=" .. folder;
    request(url);

end

function LinhVu.proxy(ip, port, enable, type)
    local url = "wifi/socks5?ipaddr=" .. ip .. "&port=" .. port .. "&setEnable=" .. enable .. "&type=" .. type;
    request(url);

end

function LinhVu.logContent()
    print("etst")
end
return LinhVu
