local LinhVu = {}

local function request(url)
    local baseUrl = "http://localhost:3004/";
    local http = require("socket.http")
    local body, code, headers, status = http.request(baseUrl .. url);
end

function LinhVu.backup(bundle)
    local url = "app/backup?bundle=" .. bundle;
    request(url);

end
function LinhVu.wipe(bundle)
    local url = "app/wipe?bundleName=" .. bundle;
    request(url);
end
function LinhVu.Fake(app, ip)
    local url = "device/changefull?ip=" .. ip;
    request(url);
end
-- http://192.168.31.27:3004/app/reset?bundleName=com.tinginteractive.usms&iokit=true&mgca=true&ip=116.103.19.129
function LinhVu.reset(app, ip)
    local url = "app/reset?bundleName=" .. app .. "&mgca=true&iokit=true&ip=" .. ip;
    request(url);
end

function LinhVu.restore(folder)
    local url = "app/restore?folder=" .. folder;
    request(url);

end

function LinhVu.delete(folder)
    local url = "app/delete?folder=" .. folder;
    request(url);

end

function LinhVu.proxy(ip, port, enable, type)
    local url = "wifi/socks5?ipaddr=" .. ip .. "&port=" .. port .. "&setEnable=" .. enable .. "&type=" .. type;
    request(url);

end

function LinhVu.getCookieTextNow(username)
    local url = "textnow/getcookie?username=" .. username;
    request(url);

end
function LinhVu.getCookieFacebook()
    local url = "facebook/cookie";
    request(url);

end

function LinhVu.logContent()
    print("etst")
end
return LinhVu
